# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "X:\\MicroBlaze_DDR_speed_test_sw\\platform\\microblaze_0\\standalone_microblaze_0\\bsp\\include\\sleep.h"
  "X:\\MicroBlaze_DDR_speed_test_sw\\platform\\microblaze_0\\standalone_microblaze_0\\bsp\\include\\xiltimer.h"
  "X:\\MicroBlaze_DDR_speed_test_sw\\platform\\microblaze_0\\standalone_microblaze_0\\bsp\\include\\xtimer_config.h"
  "X:\\MicroBlaze_DDR_speed_test_sw\\platform\\microblaze_0\\standalone_microblaze_0\\bsp\\lib\\libxiltimer.a"
  )
endif()
