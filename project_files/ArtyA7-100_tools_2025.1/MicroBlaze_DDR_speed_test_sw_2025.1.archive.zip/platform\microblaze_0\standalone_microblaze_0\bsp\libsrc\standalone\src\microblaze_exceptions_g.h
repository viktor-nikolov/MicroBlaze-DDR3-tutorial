#ifndef MICROBLAZE_EXCEPTIONS_G_H /**< prevent circular inclusions */
#define MICROBLAZE_EXCEPTIONS_G_H /**< by using protection macros */
#define MICROBLAZE_CAN_HANDLE_EXCEPTIONS_IN_DELAY_SLOTS
#define MICROBLAZE_EXCEPTIONS_ENABLED 1
#endif /* end of protection macro */
